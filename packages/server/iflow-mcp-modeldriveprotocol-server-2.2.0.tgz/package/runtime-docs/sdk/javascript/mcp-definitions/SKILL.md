# MCP Definitions

In the JavaScript SDK, you do not define MCP tools directly. You define MDP paths, and the server exposes those paths through a fixed MCP bridge surface.

## Endpoint definitions

Use `expose(path, descriptor, handler)` for regular callable endpoints.

```ts
client.expose(
  '/page/search',
  {
    method: 'POST',
    description: 'Search the current page',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string' }
      },
      required: ['query']
    }
  },
  async ({ body }, context) => {
    const query = typeof body === 'object' && body !== null && !Array.isArray(body)
      ? String((body as { query?: unknown }).query ?? '')
      : ''

    return {
      query,
      matches: 3,
      authToken: context.auth?.token
    }
  }
)
```

Endpoint descriptors use:

- `path`
- `method`
- optional `description`
- optional `inputSchema`
- optional `outputSchema`
- optional `contentType`

## Prompt definitions

Use a reserved `.../prompt.md` path for prompt documents or prompt builders.

```ts
client.expose('/selection/summarize/prompt.md', {
  description: 'Build a summarization prompt'
}, async ({ queries }) => ({
  messages: [
    {
      role: 'user',
      content: `Summarize the active selection in a ${queries.tone ?? 'neutral'} tone.`
    }
  ]
}))
```

Prompt descriptors use:

- `path`
- optional `description`
- optional `inputSchema`
- optional `outputSchema`

## Path-first registration

Register endpoint, prompt, and skill descriptors directly with `expose()`. The SDK does not require any tool-style wrapper APIs.

## How MCP sees these definitions

The canonical bridge tools are:

- `listClients`
- `listPaths`
- `callPath`
- `callPaths`

If your runtime adds or removes descriptors after `register()`, update the local registry with `expose()` / `unexpose()`, then call `syncCatalog()` so the server refreshes its indexed path catalog.

For the wire model behind those definitions, see [Capability Model](/protocol/capability-model/SKILL.md) and [MCP Bridge](/protocol/mcp-bridge/SKILL.md).
