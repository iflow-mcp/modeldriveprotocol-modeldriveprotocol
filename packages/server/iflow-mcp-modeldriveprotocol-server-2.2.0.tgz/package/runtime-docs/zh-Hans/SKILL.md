# MDP Server 内置文档

这个 server 提供两类能力：

- 固定的 MCP bridge tools，供 host 先发现 client，再按 path 调用。
- 传输与探测路由，供 MDP client 建链、鉴权、注册目录和读取 skill。

## 建议先这样用 MCP bridge tools

1. `listClients` 查看当前在线的 MDP clients。
2. `listPaths` 找到目标 client、`method` 和 canonical path。
3. `callPath` 调用一个确定 client 的一个确定 path。
4. `callPaths` 把同一个 path fan-out 到多个 client。

## 当前可访问的 transport 和 HTTP 路由

- WebSocket session: `ws://<host>:<port>`
- HTTP loop: `POST /mdp/http-loop/connect`、`POST /mdp/http-loop/send`、`GET /mdp/http-loop/poll`、`POST /mdp/http-loop/disconnect`
- Auth bootstrap: `POST /mdp/auth`、`DELETE /mdp/auth`
- Server metadata: `GET /mdp/meta`
- Skill 直读路由: `GET /skills/:clientId/*skillPath`、`GET /:clientId/skills/*skillPath`

## 下一步阅读

- [/zh-Hans/server/tools/SKILL.md](/zh-Hans/server/tools/SKILL.md)
- [/zh-Hans/server/api/SKILL.md](/zh-Hans/server/api/SKILL.md)
- [/zh-Hans/guide/quick-start/SKILL.md](/zh-Hans/guide/quick-start/SKILL.md)
- [/zh-Hans/protocol/overview/SKILL.md](/zh-Hans/protocol/overview/SKILL.md)
- [/zh-Hans/sdk/javascript/quick-start/SKILL.md](/zh-Hans/sdk/javascript/quick-start/SKILL.md)
- [/zh-Hans/playground/SKILL.md](/zh-Hans/playground/SKILL.md)
