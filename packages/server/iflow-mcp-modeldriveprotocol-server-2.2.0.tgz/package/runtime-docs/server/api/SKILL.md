# APIs

The server exposes transport-facing APIs for MDP clients. This section is split into connection setup, message events, and external interfaces.

## Read by task

| Goal                                              | Start here                                                                                                                                     |
| ------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| Open a bidirectional session                      | [WebSocket](/server/api/websocket-connection/SKILL.md)                                                                                                  |
| Use request-response transport instead of sockets | [HTTP Loop](/server/api/http-loop-connection/SKILL.md)                                                                                                  |
| Bootstrap browser auth before opening a websocket | [Auth Bootstrap](/server/api/auth-bootstrap/SKILL.md)                                                                                                   |
| Probe whether a port is serving MDP               | [GET /mdp/meta](/server/api/meta/SKILL.md)                                                                                                              |
| Update a connected client's path catalog          | [updateClientCatalog](/server/api/update-client-catalog/SKILL.md)                                                                                       |
| Look up websocket message event types             | [registerClient](/server/api/register-client/SKILL.md), [callClient](/server/api/call-client/SKILL.md), [ping](/server/api/ping/SKILL.md)                               |
| Check exact HTTP request and response contracts   | [POST /mdp/http-loop/connect](/server/api/http-loop-connect/SKILL.md), [POST /mdp/auth](/server/api/auth-issue/SKILL.md), [GET /mdp/meta](/server/api/meta/SKILL.md) |

## Connection Setup

| Surface                                       | Entry point               | Notes                                                 |
| --------------------------------------------- | ------------------------- | ----------------------------------------------------- |
| [WebSocket](/server/api/websocket-connection/SKILL.md) | `ws://127.0.0.1:47372`    | Bidirectional JSON MDP messages                       |
| [HTTP Loop](/server/api/http-loop-connection/SKILL.md) | `/mdp/http-loop/connect`  | Session-based long-poll transport                     |
| [Auth Bootstrap](/server/api/auth-bootstrap/SKILL.md)  | `/mdp/auth`               | Cookie bootstrap mainly for browser websocket clients |
| [Metadata Probe](/server/api/meta/SKILL.md)            | `/mdp/meta`               | Identify an MDP server and read discovery hints       |

## Message Events

| Event                                              | Direction        | Purpose                                   |
| -------------------------------------------------- | ---------------- | ----------------------------------------- |
| [registerClient](/server/api/register-client/SKILL.md)      | Client -> Server | Register one client descriptor and paths  |
| [updateClientCatalog](/server/api/update-client-catalog/SKILL.md) | Client -> Server | Replace one registered path catalog       |
| [unregisterClient](/server/api/unregister-client/SKILL.md)  | Client -> Server | Remove one registered client session      |
| [callClient](/server/api/call-client/SKILL.md)              | Server -> Client | Invoke one method+path target on a client |
| [callClientResult](/server/api/call-client-result/SKILL.md) | Client -> Server | Return a routed invocation result         |
| [ping](/server/api/ping/SKILL.md)                           | Both directions  | Heartbeat keepalive                       |
| [pong](/server/api/pong/SKILL.md)                           | Both directions  | Heartbeat acknowledgement                 |

## External Interfaces

| Interface                                                          | Method   | Purpose                                   |
| ------------------------------------------------------------------ | -------- | ----------------------------------------- |
| [POST /mdp/http-loop/connect](/server/api/http-loop-connect/SKILL.md)       | `POST`   | Create one HTTP loop session              |
| [POST /mdp/http-loop/send](/server/api/http-loop-send/SKILL.md)             | `POST`   | Send one client-to-server message         |
| [GET /mdp/http-loop/poll](/server/api/http-loop-poll/SKILL.md)              | `GET`    | Receive one server-to-client message      |
| [POST /mdp/http-loop/disconnect](/server/api/http-loop-disconnect/SKILL.md) | `POST`   | Close one HTTP loop session               |
| [POST /mdp/auth](/server/api/auth-issue/SKILL.md)                           | `POST`   | Issue one auth cookie                     |
| [DELETE /mdp/auth](/server/api/auth-delete/SKILL.md)                        | `DELETE` | Clear one auth cookie                     |
| [GET /mdp/meta](/server/api/meta/SKILL.md)                                  | `GET`    | Probe one server for MDP metadata         |
| [GET /skills/:clientId/*skillPath](/server/api/skill-route-direct/SKILL.md) | `GET`    | Read one skill over the direct HTTP route |
| [GET /:clientId/skills/*skillPath](/server/api/skill-route-nested/SKILL.md) | `GET`    | Read one skill over the nested HTTP route |

## Shared JSON types

`AuthContext`:

```json
{
  "scheme": "Bearer",
  "token": "client-session-token",
  "headers": {
    "x-mdp-auth-tenant": "demo"
  },
  "metadata": {
    "role": "operator"
  }
}
```

`SerializedError`:

```json
{
  "code": "handler_error",
  "message": "Something failed",
  "details": {
    "reason": "optional"
  }
}
```

MDP client catalogs are path-based. Each descriptor in `client.paths` is one of:

- an `endpoint` with an HTTP-like `method` plus `path`
- a `prompt` served at a `*.prompt.md` path and invoked with `GET`
- a `skill` served at a `*.skill.md` path and invoked with `GET`

## Relationship to bridge tools

These APIs are for MDP clients. MCP hosts do not call them directly. MCP hosts use the bridge [Tools](/server/tools/SKILL.md).
