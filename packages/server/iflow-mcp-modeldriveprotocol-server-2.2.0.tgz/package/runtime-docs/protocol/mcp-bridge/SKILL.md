# MCP Bridge

The MDP server exposes a stable MCP tool surface instead of generating tools dynamically per capability.

Bridge tools:

- `listClients`
- `listPaths`
- `callPath`
- `callPaths`

The bridge surface keeps the host integration stable while still allowing the registered path catalogs to change at runtime.

The path-oriented bridge is the surface:

- `listClients`
- `listPaths`
- `callPath`
- `callPaths`

Invocation-oriented bridge tools such as `callPath` and `callPaths` accept an optional `auth` object. That payload is forwarded to the target client as `callClient.auth`.
