# Manual Install

Use this page when you want to configure MDP explicitly instead of relying on `npx mdp setup`.

The examples below follow the client-specific installation patterns commonly used in MCP hosts. This page focuses on local MCP server setups, where the host launches MDP over `stdio`.

If you are working inside this repository checkout instead of consuming a published package, prefer the local launcher at `scripts/run-local-mdp-mcp.mjs`. That keeps the host pointed at your checked-out server code and matches what `mdp setup --scope project` writes automatically.

## Common Clients

## Claude Code
Use the Claude CLI:

```bash
claude mcp add --scope user mdp -- npx -y @modeldriveprotocol/server
```

Project scope:

```bash
claude mcp add --scope project mdp -- npx -y @modeldriveprotocol/server
```

## OpenAI Codex
Using the Codex CLI:

```bash
codex mcp add mdp -- npx -y @modeldriveprotocol/server
```

Inside this repository, prefer project scope with the local launcher:

```toml
[mcp_servers.mdp]
command = "node"
args = ["scripts/run-local-mdp-mcp.mjs"]
startup_timeout_sec = 20
```

Or add this to `~/.codex/config.toml` or `.codex/config.toml`:

```toml
[mcp_servers.mdp]
command = "npx"
args = ["-y", "@modeldriveprotocol/server"]
startup_timeout_sec = 20
```

## Google Antigravity
Add this to the Antigravity MCP config:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Cursor
Global config in `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

For one project only, use `.cursor/mcp.json`.

## OpenCode
Add this to your OpenCode config:

```json
{
  "mcp": {
    "mdp": {
      "type": "local",
      "command": ["npx", "-y", "@modeldriveprotocol/server"],
      "enabled": true
    }
  }
}
```

## VS Code
Add this to `.vscode/mcp.json`:

```json
{
  "servers": {
    "mdp": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Kiro
In `Kiro` -> `MCP Servers`, add:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## JetBrains AI Assistant
Open `Settings` -> `Tools` -> `AI Assistant` -> `Model Context Protocol (MCP)` and add:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Gemini CLI
Add this to `~/.gemini/settings.json`:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Qwen Code
Using the CLI:

```bash
qwen mcp add mdp npx -y @modeldriveprotocol/server
```

Or add this to `~/.qwen/settings.json` or `.qwen/settings.json`:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Amazon Q Developer CLI
Add this to the Amazon Q Developer CLI MCP config:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Warp
In `Settings` -> `AI` -> `Manage MCP servers`, paste:

```json
{
  "MDP": {
    "command": "npx",
    "args": ["-y", "@modeldriveprotocol/server"],
    "env": {},
    "working_directory": null,
    "start_on_launch": true
  }
}
```

## Zed
Add this to your Zed `settings.json`:

```json
{
  "context_servers": {
    "MDP": {
      "source": "custom",
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Trae
Use the Add manually flow and paste:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Roo Code
Add this to the Roo Code MCP config:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Augment Code
In `settings.json`, add the server inside `augment.advanced.mcpServers`:

```json
{
  "augment.advanced": {
    "mcpServers": [
      {
        "name": "mdp",
        "command": "npx",
        "args": ["-y", "@modeldriveprotocol/server"]
      }
    ]
  }
}
```

## LM Studio
Open `Program` -> `Install` -> `Edit mcp.json` and add:

```json
{
  "mcpServers": {
    "MDP": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Visual Studio 2022
Add this to the MCP server config:

```json
{
  "mcp": {
    "servers": {
      "mdp": {
        "type": "stdio",
        "command": "npx",
        "args": ["-y", "@modeldriveprotocol/server"]
      }
    }
  }
}
```

## Crush
Add this to your Crush config:

```json
{
  "$schema": "https://charm.land/crush.json",
  "mcp": {
    "mdp": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## BoltAI
In `Settings` -> `Plugins`, enter:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Rovo Dev CLI
Open the Rovo Dev CLI MCP config:

```bash
acli rovodev mcp
```

Then add:

```json
{
  "mcpServers": {
    "mdp": {
      "command": "npx",
      "args": ["-y", "@modeldriveprotocol/server"]
    }
  }
}
```

## Zencoder
In `Agent tools` -> `Add custom MCP`, use:

```json
{
  "command": "npx",
  "args": ["-y", "@modeldriveprotocol/server"]
}
```

## Related Pages

- [Quick Start](/guide/quick-start/SKILL.md)
- [CLI Reference](/server/cli/SKILL.md)
- [Deployment Modes](/server/deployment/SKILL.md)
