# MDP Server Runtime Docs

This server exposes two complementary surfaces:

- fixed MCP bridge tools for hosts
- transport and discovery routes for MDP clients

## Recommended bridge tool flow

1. `listClients` shows which MDP clients are currently online.
2. `listPaths` lets you inspect each client path catalog and find the exact target.
3. `callPath` invokes one exact `method + path` on one exact client.
4. `callPaths` fans the same invocation out to multiple clients.

## Transport and HTTP routes

- WebSocket session: `ws://<host>:<port>`
- HTTP loop: `POST /mdp/http-loop/connect`, `POST /mdp/http-loop/send`, `GET /mdp/http-loop/poll`, `POST /mdp/http-loop/disconnect`
- Auth bootstrap: `POST /mdp/auth`, `DELETE /mdp/auth`
- Server metadata probe: `GET /mdp/meta`
- Direct skill reads: `GET /skills/:clientId/*skillPath`, `GET /:clientId/skills/*skillPath`

## Read next

- [/server/tools/SKILL.md](/server/tools/SKILL.md)
- [/server/api/SKILL.md](/server/api/SKILL.md)
- [/guide/quick-start/SKILL.md](/guide/quick-start/SKILL.md)
- [/protocol/overview/SKILL.md](/protocol/overview/SKILL.md)
- [/sdk/javascript/quick-start/SKILL.md](/sdk/javascript/quick-start/SKILL.md)
- [/playground/SKILL.md](/playground/SKILL.md)
